package collectionDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class demoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Address> address1=new ArrayList<>();
		address1.add(new Address(1,"Sri ram Avenue","Chennai"));
		address1.add(new Address(2,"Abhirami nagar","Nellai"));
		List<Address> address2=new ArrayList<>();
		address2.add(new Address(3,"Sri ram Avenue","Coimbatore"));
		address2.add(new Address(4,"Abhirami nagar","Madurai"));
		List<Address> address3=new ArrayList<>();
		address3.add(new Address(5,"Sri ram Avenue","Trichy"));
		address3.add(new Address(6,"Abhirami nagar","Pondicherry"));
		List<Employee> empList=new ArrayList<>();
		empList.add(new Employee(1,"Kumutha","lakshmi",10000,new Department(12, "Finance", "Chennai"),address1));
		empList.add(new Employee(2,"Subhadra","Murugan",25000,new Department(14, "Networks", "Trichy"),address2));
		empList.add(new Employee(3,"Sumithra","Murugan",20000,new Department(22, "ENGNE", "Madurai"),address3));
		
		Comparator<Employee> sortByEmpid=new Comparator<Employee>() {
			
			@Override
			public int compare(Employee o1, Employee o2) {
				if(o1.getEmployeeId()>o2.getEmployeeId())
					return 1;
				else if(o1.getEmployeeId()<o2.getEmployeeId())
					return -1;
				else
				return 0;
			}
		};
		Comparator<Employee> sortByFirstname=new Comparator<Employee>() {
			
			@Override
			public int compare(Employee o1, Employee o2) {
				
				return o1.getFirstName().compareTo(o2.getFirstName());
			}
		};
		
		Comparator<Employee> sortBySalary=new Comparator<Employee>() {
			
			@Override
			public int compare(Employee o1, Employee o2) {
				if(o1.getSalary()>o2.getSalary())
					return 1;
				else if(o1.getSalary()<o2.getSalary())
					return -1;
				else
				return 0;
			}
		};
Comparator<Employee> sortByDeptLoc=new Comparator<Employee>() {
			
			@Override
			public int compare(Employee o1, Employee o2) {
				
				return o1.getDepartment().getLocation().compareTo(o2.getDepartment().getLocation());
			}
		};
		
		//Collections.sort(empList,sortByEmpid);
		//Collections.sort(empList, sortByFirstname);
		//Collections.sort(empList,sortBySalary);
		//Collections.sort(empList,sortByDeptLoc);
		for (Employee employee : empList) {
			
			System.out.println("EmployeeId: "+employee.getEmployeeId()+" Firstname: "+employee.getFirstName()+" LastName: "+employee.getLastName()+" Salary: "+employee.salary);
			Department dept=new Department();
			dept=employee.getDepartment();
			System.out.print("Departname ID:"+dept.getDeptId()+" Dept name: "+dept.getDeptName()+" Location: "+dept.getLocation()+" Address: [");
			List<Address> ad=new ArrayList<>();
			ad=employee.getAddress();
			for(Address adr:ad)
			{
				System.out.print("Address Id: "+adr.getAddressId()+" StreetName: "+adr.getStreetName()+" City: "+adr.getCity());
			}
			System.out.println("]");
		}
	}

}
